import { motion } from "motion/react";
import { cn } from "../lib/utils";

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  index: number;
}

export function FeatureCard({ icon, title, description, index }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className={cn(
        "bg-white rounded-2xl p-6 md:p-8 border border-borderLight shadow-sm hover:shadow-premium transition-all duration-300",
        "group hover:-translate-y-1"
      )}
    >
      <div className="w-12 h-12 rounded-xl bg-pale text-primary flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-primary group-hover:text-white transition-all duration-300">
        {icon}
      </div>
      <h3 className="text-xl font-bold text-navy mb-3">{title}</h3>
      <p className="text-slate leading-relaxed">
        {description}
      </p>
    </motion.div>
  );
}
