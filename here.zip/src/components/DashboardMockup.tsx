import { motion } from "motion/react";
import { LayoutDashboard, Receipt, Package, FileText, Settings, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cn } from "../lib/utils";

export function DashboardMockup({ className }: { className?: string }) {
  return (
    <div className={cn("relative rounded-2xl border border-borderLight bg-white shadow-premium overflow-hidden w-full aspect-[4/3] max-w-[800px] flex", className)}>
      {/* Sidebar */}
      <div className="w-[200px] bg-slate-50 border-r border-borderLight flex flex-col hidden sm:flex">
        <div className="p-4 flex items-center gap-2 border-b border-borderLight">
          <div className="w-6 h-6 rounded bg-primary text-white flex items-center justify-center font-bold text-xs">
            K
          </div>
          <span className="font-semibold text-sm text-navy">Khatakitab</span>
        </div>
        <div className="flex-1 py-4 px-3 space-y-1">
          <div className="flex items-center gap-3 px-3 py-2 bg-primary/10 text-primary rounded-lg text-sm font-medium">
            <LayoutDashboard size={16} />
            Dashboard
          </div>
          {[
            { icon: Receipt, label: "Sales" },
            { icon: Package, label: "Purchases" },
            { icon: Package, label: "Inventory" },
            { icon: FileText, label: "Reports" },
            { icon: Settings, label: "Settings" },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-3 px-3 py-2 text-slate hover:bg-slate-100 hover:text-navy rounded-lg text-sm transition-colors">
              <item.icon size={16} />
              {item.label}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden bg-white">
        <div className="h-14 border-b border-borderLight flex items-center justify-between px-6">
          <h2 className="font-semibold text-navy text-sm sm:text-base">Dashboard</h2>
          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 text-xs text-slate bg-pale rounded-full border border-borderLight">
              01 Oct 2026 - 31 Oct 2026
            </div>
          </div>
        </div>
        
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { label: "Total Income", value: "₹ 1,32,480", trend: "+12%", up: true },
              { label: "Total Expenses", value: "₹ 68,230", trend: "-5%", up: false },
              { label: "Profit", value: "₹ 64,250", trend: "+15%", up: true, highlight: true },
            ].map((stat, i) => (
              <div key={i} className={cn("p-4 rounded-xl border border-borderLight", stat.highlight ? "bg-pale border-primary/20" : "bg-white")}>
                <div className="text-xs text-slate mb-1">{stat.label}</div>
                <div className={cn("text-xl sm:text-2xl font-bold mb-2", stat.highlight ? "text-primary" : "text-navy")}>{stat.value}</div>
                <div className={cn("flex items-center gap-1 text-[10px] font-medium", stat.up ? "text-success" : "text-red-500")}>
                  {stat.up ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {stat.trend}
                </div>
              </div>
            ))}
          </div>

          {/* Chart area */}
          <div className="border border-borderLight rounded-xl p-4 sm:p-5 h-[200px] flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-navy">Income vs Expenses</h3>
              <div className="flex items-center gap-3 text-[10px] text-slate">
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-primary"></div>Income</div>
                <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-accent"></div>Expenses</div>
              </div>
            </div>
            <div className="flex-1 flex items-end justify-between gap-1 sm:gap-2 px-2 relative">
              {/* Chart lines */}
              <div className="absolute left-0 top-0 bottom-0 w-full flex flex-col justify-between text-[10px] text-slate/50">
                <span>100k</span><span>50k</span><span>0</span>
              </div>
              <div className="w-6 border-l border-borderLight h-full absolute left-0" />
              <div className="w-full border-b border-borderLight absolute bottom-0" />
              
              {/* Bars */}
              {Array.from({ length: 12 }).map((_, i) => {
                const incomeH = 40 + Math.random() * 50;
                const expH = 20 + Math.random() * 40;
                return (
                  <div key={i} className="relative z-10 w-full max-w-[12px] sm:max-w-[16px] h-full flex items-end justify-center gap-[1px]">
                    <motion.div 
                      initial={{ height: 0 }}
                      whileInView={{ height: `${incomeH}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: i * 0.05 }}
                      className="w-1/2 bg-primary rounded-t-sm"
                    />
                    <motion.div 
                      initial={{ height: 0 }}
                      whileInView={{ height: `${expH}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.8, delay: i * 0.05 + 0.1 }}
                      className="w-1/2 bg-accent rounded-t-sm"
                    />
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between px-6 mt-2 text-[8px] sm:text-[10px] text-slate">
              <span>Oct 1</span><span>Oct 7</span><span>Oct 14</span><span>Oct 21</span><span>Oct 28</span>
            </div>
          </div>

          {/* Table */}
          <div>
            <h3 className="text-sm font-semibold text-navy mb-3">Top Products</h3>
            <div className="border border-borderLight rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate border-b border-borderLight">
                  <tr>
                    <th className="font-medium p-3">Product</th>
                    <th className="font-medium p-3">Quantity Sold</th>
                    <th className="font-medium p-3 text-right">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-borderLight">
                  {[
                    { name: "Rice (25kg)", qty: "120 bag", rev: "₹ 6,300" },
                    { name: "Sugar (1kg)", qty: "80 kg", rev: "₹ 4,800" },
                    { name: "Cooking Oil (1L)", qty: "65 ltr", rev: "₹ 4,200" },
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-slate-50/50">
                      <td className="p-3 text-navy">{row.name}</td>
                      <td className="p-3 text-slate">{row.qty}</td>
                      <td className="p-3 text-navy font-medium text-right">{row.rev}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
