import { cn } from "../lib/utils";

interface SectionHeadingProps {
  pill?: string;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  centered?: boolean;
  className?: string;
}

export function SectionHeading({ pill, title, subtitle, centered = false, className }: SectionHeadingProps) {
  return (
    <div className={cn("max-w-3xl", centered && "mx-auto text-center", className)}>
      {pill && (
        <span className="inline-block px-3 py-1 mb-4 text-xs font-semibold text-primary bg-pale rounded-full">
          {pill}
        </span>
      )}
      <h2 className={cn(
        "text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-navy mb-4 text-balance",
      )}>
        {title}
      </h2>
      {subtitle && (
        <p className="text-lg text-slate text-balance">
          {subtitle}
        </p>
      )}
    </div>
  );
}
