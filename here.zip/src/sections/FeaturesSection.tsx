import { SectionHeading } from "../components/SectionHeading";
import { FeatureCard } from "../components/FeatureCard";
import { BarChart3, Package, FilePieChart, WifiOff, Cloud, Store } from "lucide-react";

export function FeaturesSection() {
  const features = [
    {
      icon: <BarChart3 size={24} />,
      title: "Income & Expense Tracking",
      description: "Keep a clear record of your daily income, expenses and overall profit without complex spreadsheets."
    },
    {
      icon: <Package size={24} />,
      title: "Inventory Management",
      description: "Track stock, get low stock alerts and never run out of essentials. Update quantities with a single tap."
    },
    {
      icon: <FilePieChart size={24} />,
      title: "Reports & Insights",
      description: "View simple and clear reports to understand trends and make better business decisions."
    },
    {
      icon: <WifiOff size={24} />,
      title: "Offline First",
      description: "Work without internet and seamlessly sync your data securely when you're back online."
    },
    {
      icon: <Cloud size={24} />,
      title: "Secure Backup",
      description: "Automatically back up your data to email or Google Drive. Recover your business data if you lose your phone."
    },
    {
      icon: <Store size={24} />,
      title: "Multi-Business Support",
      description: "Manage multiple shops or business types from one app with separate tracking and reports."
    }
  ];

  return (
    <section id="features" className="py-24 bg-white">
      <div className="container mx-auto px-6 max-w-7xl">
        <SectionHeading
          centered
          pill="Everything You Need"
          title="Powerful Features for Your Business"
          subtitle="From daily transactions to detailed reports — Khatakitab gives you the tools to run your business better, faster and smarter."
          className="mb-16"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <FeatureCard
              key={i}
              index={i}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
