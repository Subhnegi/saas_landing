import { motion } from "motion/react";
import { SectionHeading } from "../components/SectionHeading";
import { Star } from "lucide-react";

export function TestimonialsSection() {
  const testimonials = [
    {
      text: "Khatakitab has made my grocery shop management so much easier. I can now track everything from my phone, even without internet. Highly recommended!",
      author: "Ramesh Kumar",
      role: "Grocery Store Owner",
      avatar: "R"
    },
    {
      text: "The inventory alerts are a lifesaver! I no longer run out of stock, and the daily profit reports help me plan my purchases much better than before.",
      author: "Priya Sharma",
      role: "Clothing Store Owner",
      avatar: "P"
    },
    {
      text: "Simple, clean and super useful. Exactly what small businesses like ours need. The offline backup feature gives me total peace of mind.",
      author: "Amit Verma",
      role: "Salon Owner",
      avatar: "A"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6 max-w-7xl">
        <SectionHeading
          centered
          pill="Loved by Small Business Owners"
          title="What Our Users Say"
          subtitle="Sample testimonials demonstrating how Khatakitab can help owners manage their daily operations."
          className="mb-16"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.15 }}
              className="p-8 rounded-2xl bg-white border border-borderLight shadow-sm hover:shadow-soft transition-shadow flex flex-col"
            >
              <div className="flex gap-1 text-yellow-400 mb-6">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} size={18} fill="currentColor" />
                ))}
              </div>
              <p className="text-slate leading-relaxed mb-8 flex-1 italic">
                "{testimonial.text}"
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center font-bold text-navy border border-borderLight">
                  {testimonial.avatar}
                </div>
                <div>
                  <h4 className="font-semibold text-navy">{testimonial.author}</h4>
                  <p className="text-xs text-slate">{testimonial.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
