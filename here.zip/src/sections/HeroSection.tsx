import { motion } from "motion/react";
import { Play, ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "../components/Button";
import { DashboardMockup } from "../components/DashboardMockup";
import { PhoneMockup } from "../components/PhoneMockup";

interface HeroSectionProps {
  onOpenDemo: () => void;
}

export function HeroSection({ onOpenDemo }: HeroSectionProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <section id="home" className="pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden relative">
      {/* Background elements */}
      <div className="absolute top-0 inset-x-0 h-full bg-gradient-to-b from-pale/80 to-white -z-10" />
      <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] rounded-full bg-primary/5 blur-[120px] -z-10" />
      
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="flex flex-col lg:flex-row items-center gap-16 lg:gap-8">
          
          {/* Left Column - Content */}
          <motion.div 
            className="flex-1 max-w-2xl lg:pr-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-pale border border-primary/20 text-primary text-xs font-semibold mb-6">
              <Store size={14} />
              Built for Small Businesses
            </motion.div>
            
            <motion.h1 variants={itemVariants} className="text-4xl md:text-5xl lg:text-[56px] font-bold text-navy leading-[1.1] tracking-tight mb-6 text-balance">
              Manage Your Business Finances, Inventory & More — <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">All in One Place</span>
            </motion.h1>
            
            <motion.p variants={itemVariants} className="text-lg text-slate mb-8 leading-relaxed text-balance max-w-xl">
              Khatakitab helps small businesses like yours track income, expenses, inventory and profits — simple, fast and offline first. Work on your phone, even without internet.
            </motion.p>
            
            <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-10">
              <Button size="lg" className="w-full sm:w-auto group">
                Get Started Free
                <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button size="lg" variant="outline" className="w-full sm:w-auto group" onClick={onOpenDemo}>
                <div className="w-6 h-6 rounded-full bg-pale text-primary flex items-center justify-center mr-2 group-hover:bg-primary group-hover:text-white transition-colors">
                  <Play size={12} className="ml-0.5" />
                </div>
                Watch Demo
              </Button>
            </motion.div>
            
            <motion.div variants={itemVariants} className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm font-medium text-slate">
              {[
                "Works Offline",
                "Data Backup",
                "No Credit Card Required"
              ].map((point, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-success" />
                  {point}
                </div>
              ))}
            </motion.div>
          </motion.div>
          
          {/* Right Column - Mockups */}
          <div className="flex-1 w-full relative h-[400px] sm:h-[500px] lg:h-[600px] flex items-center justify-center lg:justify-end perspective-1000">
            <motion.div
              initial={{ opacity: 0, x: 40, rotateY: -10 }}
              animate={{ opacity: 1, x: 0, rotateY: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="absolute right-0 sm:right-8 lg:right-0 w-[90%] sm:w-[80%] max-w-[800px] z-10"
            >
              <DashboardMockup />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 40, x: -20 }}
              animate={{ opacity: 1, y: 0, x: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="absolute left-0 sm:left-12 lg:left-[-10%] bottom-0 sm:bottom-12 z-20"
            >
              <PhoneMockup />
            </motion.div>
            
            {/* Decorative elements */}
            <motion.div
              animate={{ y: [-10, 10, -10] }}
              transition={{ repeat: Infinity, duration: 6, ease: "easeInOut" }}
              className="absolute right-20 top-20 w-16 h-16 bg-white rounded-2xl shadow-premium border border-borderLight flex items-center justify-center text-success z-0 hidden md:flex"
            >
              <div className="flex items-center gap-1 font-bold">
                +24%
              </div>
            </motion.div>
          </div>
          
        </div>
      </div>
    </section>
  );
}

// Ensure lucide icon imports matching the brief
import { Store } from "lucide-react";
