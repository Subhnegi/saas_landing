import { motion } from "motion/react";
import { SectionHeading } from "../components/SectionHeading";
import { ArrowRight, BarChart2, Package, Check } from "lucide-react";

export function HowItWorksSection() {
  const steps = [
    {
      num: 1,
      title: "Choose Your Business Type",
      desc: "Select from grocery, tailor, salon, clothes, and more — or add your own custom type.",
    },
    {
      num: 2,
      title: "Add Your Details",
      desc: "Set up your inventory items, products and basic business settings in seconds.",
    },
    {
      num: 3,
      title: "Start Managing",
      desc: "Track sales, expenses, inventory and view insightful reports — all in one place.",
    },
  ];

  return (
    <section id="how-it-works" className="py-24 bg-pale">
      <div className="container mx-auto px-6 max-w-7xl">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          
          <div className="flex-1 lg:pr-10">
            <SectionHeading
              pill="Get Started in 3 Easy Steps"
              title="How It Works"
              subtitle="Set up your business in minutes and start managing your finances right away without any complex onboarding."
              className="mb-12"
            />
            
            <div className="space-y-8 relative">
              <div className="absolute left-6 top-8 bottom-8 w-px bg-borderLight hidden md:block" />
              
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ duration: 0.5, delay: i * 0.2 }}
                  className="relative flex items-start gap-6 group"
                >
                  <div className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-lg shrink-0 shadow-soft group-hover:scale-110 transition-transform relative z-10">
                    {step.num}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-navy mb-2">{step.title}</h3>
                    <p className="text-slate leading-relaxed">{step.desc}</p>
                  </div>
                  
                  {i < steps.length - 1 && (
                    <div className="absolute top-1/2 right-0 md:hidden">
                      <ArrowRight className="text-borderLight" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
          
          <div className="flex-1 w-full max-w-md lg:max-w-none">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="relative aspect-square max-h-[500px] w-full mx-auto"
            >
              {/* Illustration Scene built with CSS/SVG */}
              <div className="absolute inset-0 bg-gradient-to-br from-white to-pale border border-borderLight rounded-full shadow-premium flex items-center justify-center overflow-hidden">
                <div className="w-3/4 h-3/4 relative">
                  {/* Backdrop */}
                  <div className="absolute bottom-0 w-full h-1/3 bg-slate-100 rounded-xl rounded-b-none" />
                  
                  {/* UI Elements floating */}
                  <motion.div 
                    animate={{ y: [0, -15, 0] }}
                    transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                    className="absolute top-10 right-10 w-24 h-24 bg-white rounded-2xl shadow-premium border border-borderLight flex items-center justify-center text-primary"
                  >
                    <Package size={40} />
                  </motion.div>
                  
                  <motion.div 
                    animate={{ y: [0, 15, 0] }}
                    transition={{ repeat: Infinity, duration: 5, ease: "easeInOut", delay: 1 }}
                    className="absolute top-1/4 left-0 w-20 h-20 bg-white rounded-2xl shadow-premium border border-borderLight flex items-center justify-center text-accent"
                  >
                    <BarChart2 size={32} />
                  </motion.div>
                  
                  <motion.div 
                    animate={{ y: [0, -10, 0] }}
                    transition={{ repeat: Infinity, duration: 3.5, ease: "easeInOut", delay: 0.5 }}
                    className="absolute bottom-1/4 left-1/4 w-12 h-12 bg-success text-white rounded-full shadow-premium flex items-center justify-center font-bold text-xl"
                  >
                    ₹
                  </motion.div>
                  
                  {/* Central Character/Device Focus */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 w-48 h-64 bg-white rounded-t-3xl border border-borderLight shadow-premium flex flex-col overflow-hidden z-10">
                    <div className="h-6 bg-slate-50 border-b border-borderLight flex items-center px-4">
                      <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto" />
                    </div>
                    <div className="p-4 flex flex-col gap-3">
                      <div className="h-4 w-1/2 bg-slate-200 rounded" />
                      <div className="flex gap-2">
                        <div className="h-16 flex-1 bg-primary/10 rounded-lg flex items-center justify-center"><Check className="text-primary opacity-50" /></div>
                        <div className="h-16 flex-1 bg-accent/10 rounded-lg" />
                      </div>
                      <div className="h-3 w-full bg-slate-100 rounded mt-auto" />
                      <div className="h-3 w-3/4 bg-slate-100 rounded" />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
          
        </div>
      </div>
    </section>
  );
}
