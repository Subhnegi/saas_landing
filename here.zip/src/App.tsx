import { useState } from "react";
import { Navbar } from "./components/Navbar";
import { HeroSection } from "./sections/HeroSection";
import { FeaturesSection } from "./sections/FeaturesSection";
import { HowItWorksSection } from "./sections/HowItWorksSection";
import { TestimonialsSection } from "./sections/TestimonialsSection";
import { FinalCtaSection } from "./sections/FinalCtaSection";
import { Footer } from "./components/Footer";
import { DemoModal } from "./components/DemoModal";

function App() {
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white selection:bg-primary/20 selection:text-primary">
      <Navbar />
      
      <main>
        <HeroSection onOpenDemo={() => setIsDemoModalOpen(true)} />
        <FeaturesSection />
        <HowItWorksSection />
        <TestimonialsSection />
        <FinalCtaSection />
      </main>
      
      <Footer />
      
      <DemoModal 
        isOpen={isDemoModalOpen} 
        onClose={() => setIsDemoModalOpen(false)} 
      />
    </div>
  );
}

export default App;
